
import java.io.IOException;
import java.sql.SQLException;
import  BankingSystem.InvalidAccountNumberException;
import BankingSystem.InsufficientFundsException;
public class Main {
    public static void main(String[] args) throws SQLException, IOException, InsufficientFundsException, InvalidAccountNumberException {
//        Transaction t = new Transaction( "0465", 3000, "d");
//        t.viewTansaction();
//        t.ToDatabase();
//        Account a = new Account("Waseem Abbas", "04657900820", 50000);
//        a.viewBalance();
//        a.ToDatabase();

//        //////////////////
//        BankingSystem b1=new BankingSystem("HBL",333,"Lahore");
//        b1.createAccount("Abid","3",4400);
//        b1.performTransaction("2",1000,"d");
//        System.out.println("\n\n\n\nHistory\n\n\n");
//        b1.viewTransactionHistory();


    }
}
